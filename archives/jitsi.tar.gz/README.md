# Jitsi Ferdi Plugin

This is unofficial [Jitsi](https://meet.jit.si) recipe for Ferdi

Follow instructions [here](https://github.com/getferdi/recipes/blob/master/docs/integration.md) for installation of this plugin.

